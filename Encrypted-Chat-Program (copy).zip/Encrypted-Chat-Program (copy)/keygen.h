

void fillKeyTable(int length, char* key);
